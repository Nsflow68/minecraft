Any server configs put in this folder will override the corresponding server config from <instance path>/config/<config path>.
If the config being transferred is in a subfolder of the base config folder make sure to include that folder here in the path to the file you are overwriting.
For example if you are overwriting a config with the path <instance path>/config/ExampleMod/config-server.toml, you would need to put it in serverconfig/ExampleMod/config-server.toml
